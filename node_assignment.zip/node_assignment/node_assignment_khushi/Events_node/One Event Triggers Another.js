const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("event1", () => {
    console.log("Event 1 Executed");
    emitter.emit("event2");
});

emitter.on("event2", () => {
    console.log("Event 2 Executed");
});

emitter.emit("event1");
const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("test", () => {
    console.log("Listener 1 Executed");
});

emitter.on("test", () => {
    console.log("Listener 2 Executed");
});

emitter.emit("test");
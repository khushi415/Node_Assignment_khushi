const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("orderPlaced", (orderId) => {
    console.log("Order ID:", orderId);
    console.log("Invoice Generated");
});

emitter.emit("orderPlaced", 1001);
const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("userLogin", (name) => {
    console.log(name + " Logged In Successfully");
});

emitter.emit("userLogin", "Karuna");
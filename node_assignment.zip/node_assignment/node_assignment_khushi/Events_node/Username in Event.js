const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("greet", (username) => {
    console.log("Welcome " + username);
});

emitter.emit("greet", "Karuna");
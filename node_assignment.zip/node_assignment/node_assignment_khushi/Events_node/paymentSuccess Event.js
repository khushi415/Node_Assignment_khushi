const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("paymentSuccess", () => {
    console.log("Payment Successful");
    console.log("Notification Sent");
});

emitter.emit("paymentSuccess");
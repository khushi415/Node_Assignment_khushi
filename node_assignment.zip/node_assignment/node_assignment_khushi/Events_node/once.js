const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.once("login", () => {
    console.log("Executed Only Once");
});

emitter.emit("login");
emitter.emit("login");
const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("orderPlaced", () => {
    console.log("Order Placed");
    emitter.emit("invoiceGenerated");
});

emitter.on("invoiceGenerated", () => {
    console.log("Invoice Generated");
    emitter.emit("notificationSent");
});

emitter.on("notificationSent", () => {
    console.log("Notification Sent");
    emitter.emit("deliveryStarted");
});

emitter.on("deliveryStarted", () => {
    console.log("Delivery Started");
});

emitter.emit("orderPlaced");
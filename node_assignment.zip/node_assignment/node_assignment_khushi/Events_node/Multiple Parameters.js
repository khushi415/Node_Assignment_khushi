const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("userDetails", (name, email, city) => {
    console.log("Name:", name);
    console.log("Email:", email);
    console.log("City:", city);
});

emitter.emit(
    "userDetails",
    "Karuna",
    "karuna@gmail.com",
    "Delhi"
);
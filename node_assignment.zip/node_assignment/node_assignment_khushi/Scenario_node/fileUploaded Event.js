const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("fileUploaded", (fileName) => {
    console.log("File Uploaded:", fileName);
});

emitter.emit("fileUploaded", "report.pdf");
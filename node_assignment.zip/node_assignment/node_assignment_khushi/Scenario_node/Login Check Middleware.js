const express = require("express");
const app = express();

const isLoggedIn = (req, res, next) => {
    if (req.query.login === "true") {
        next();
    } else {
        res.send("Please Login First");
    }
};

app.get("/dashboard", isLoggedIn, (req, res) => {
    res.send("Welcome to Dashboard");
});

app.listen(3000);
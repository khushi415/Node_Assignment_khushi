const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("paymentSuccess", () => {
    console.log("Email Sent");
    console.log("SMS Sent");
});

emitter.emit("paymentSuccess");
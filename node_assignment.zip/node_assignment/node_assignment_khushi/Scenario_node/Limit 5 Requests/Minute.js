const express = require("express");
const app = express();

let count = 0;

app.use((req, res, next) => {
    count++;

    if (count > 5) {
        return res.send("Request Limit Exceeded");
    }

    next();
});

app.get("/", (req, res) => {
    res.send("Request Allowed");
});

app.listen(3000);
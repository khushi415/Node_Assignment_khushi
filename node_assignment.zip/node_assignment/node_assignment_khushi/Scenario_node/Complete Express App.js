const express = require("express");
const EventEmitter = require("events");

const app = express();
const emitter = new EventEmitter();

// Custom Middleware
app.use((req, res, next) => {
    console.log("Request Received");
    next();
});

// Logger Middleware
app.use((req, res, next) => {
    console.log(req.method, req.url);
    next();
});

// Authentication Middleware
const auth = (req, res, next) => {
    if (req.query.token === "12345") {
        emitter.emit("login", "Karuna");
        next();
    } else {
        res.send("Unauthorized");
    }
};

// Events
emitter.on("login", (user) => {
    console.log(user + " Logged In");
});

emitter.on("logout", (user) => {
    console.log(user + " Logged Out");
});

app.get("/home", auth, (req, res) => {
    res.send("Welcome Home");
});

app.get("/logout", (req, res) => {
    emitter.emit("logout", "Karuna");
    res.send("Logged Out");
});

app.listen(3000, () => {
    console.log("Server Running");
});
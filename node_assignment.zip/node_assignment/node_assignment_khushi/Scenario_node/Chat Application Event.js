const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("message", (msg) => {
    console.log("Message Received:", msg);
});

emitter.emit("message", "Hello Everyone!");
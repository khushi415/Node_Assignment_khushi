const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("register", (name) => {
    console.log(name + " Registered Successfully");
});

emitter.emit("register", "Karuna");
const express = require("express");
const app = express();

let logs = [];

app.use((req, res, next) => {
    logs.push({
        method: req.method,
        url: req.url
    });

    console.log(logs);
    next();
});

app.get("/", (req, res) => {
    res.send("Request Logged");
});

app.listen(3000);
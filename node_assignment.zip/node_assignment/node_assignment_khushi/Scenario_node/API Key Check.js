const express = require("express");
const app = express();

const checkApiKey = (req, res, next) => {

    const apiKey = req.query.key;

    if (apiKey === "12345") {
        next();
    } else {
        res.send("Invalid API Key");
    }
};

app.get("/data", checkApiKey, (req, res) => {
    res.send("API Access Granted");
});

app.listen(3000);
const express = require("express");
const app = express();

const ageCheck = (req, res, next) => {
    const age = parseInt(req.query.age);

    if (age >= 18) {
        next();
    } else {
        res.send("Access Denied! Age must be 18+");
    }
};

app.get("/vote", ageCheck, (req, res) => {
    res.send("Welcome! You can vote.");
});

app.listen(3000, () => {
    console.log("Server Running");
});
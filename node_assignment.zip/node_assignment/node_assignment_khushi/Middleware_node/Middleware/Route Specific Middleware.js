const express = require("express");
const app = express();

const adminMiddleware = (req, res, next) => {
    console.log("Admin Middleware Executed");
    next();
};

app.get("/admin", adminMiddleware, (req, res) => {
    res.send("Admin Page");
});

app.listen(3000);
const express = require("express");
const app = express();

app.use(express.json());

const validateEmail = (req, res, next) => {
    if (req.body.email) {
        next();
    } else {
        res.send("Email Required");
    }
};

app.post("/register", validateEmail, (req, res) => {
    res.send("Registration Successful");
});

app.listen(3000);
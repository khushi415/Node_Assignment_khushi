const express = require("express");
const app = express();

const auth = (req, res, next) => {
    const token = req.query.token;

    if (token === "12345") {
        next();
    } else {
        res.send("Unauthorized");
    }
};

app.get("/secure", auth, (req, res) => {
    res.send("Welcome User");
});

app.listen(3000);
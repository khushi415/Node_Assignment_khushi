const express = require("express");
const app = express();

let count = 0;

app.use((req, res, next) => {
    count++;
    console.log("Total Requests:", count);
    next();
});

app.get("/", (req, res) => {
    res.send("Request Counted");
});

app.listen(3000);
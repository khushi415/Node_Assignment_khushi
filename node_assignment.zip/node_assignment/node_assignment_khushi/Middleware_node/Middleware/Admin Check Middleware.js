const express = require("express");
const app = express();

const isAdmin = (req, res, next) => {
    if (req.query.role === "admin") {
        next();
    } else {
        res.send("Access Denied");
    }
};

app.get("/dashboard", isAdmin, (req, res) => {
    res.send("Welcome Admin");
});

app.listen(3000);
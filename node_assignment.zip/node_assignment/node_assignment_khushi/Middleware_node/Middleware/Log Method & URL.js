const express = require("express");
const app = express();

app.use((req, res, next) => {
    console.log("Method:", req.method);
    console.log("URL:", req.url);
    next();
});

app.get("/", (req, res) => {
    res.send("Logged");
});

app.listen(3000);